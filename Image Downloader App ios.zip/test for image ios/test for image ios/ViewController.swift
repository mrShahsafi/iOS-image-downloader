//
//  ViewController.swift
//  test for image ios
//
//  Created by amirosein on 10/30/18.
//  Copyright © 2018 amirosein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

@IBOutlet weak var GetURL: UITextField!
    
    @IBOutlet weak var RepImage: UIImageView!
    
    //let urlkey = "https://www.gettyimages.ie/gi-resources/images/Homepage/Hero/UK/CMS_Creative_164657191_Kingfisher.jpg"
    
    @IBAction func DownClick(_ sender: Any) {
        let urlkey = GetURL.text
        if let url = URL(string: urlkey!){
            do{
                let data = try Data(contentsOf: url)
                
                self.RepImage.image=UIImage(data:data)
                
            }catch let err{
                print("Error: \(err.localizedDescription)")
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

